import numpy as np
import pickle
import pandas as pd
import math
import os
import scipy
import numba
import pandapower as pp
import geopandas as gp
import glob

mwd = 'C:\\Location'
insert = mwd +'GIS_Data\\'
output = mwd+'Network_DSS\\'
other = mwd+'Other\\'
lc_path =mwd+'Load_Curves\\' 
gc_path =mwd+'Gen_Curves\\'

f = open(insert+'PP_network_data_SP53224.pckl','rb')
LV_Nodes, LV_joints, LV_Branches, HV_Branches, HV_joints, Secondaries, Primaries, Links = pickle.load(f)

a = open(insert+'load_buses_SP53224.pckl','rb')
load_buses = pickle.load(a)
f.close()

#%%
#=============================================================================
## Master ##

Sourcebus = 'Sourcebus'

f = open(output+'Master.txt','w')
f.write(

'Clear \n'
'Set DefaultBaseFrequency=50 \n'
'New Circuit.SPEN_Network \n'
'~ "Vsource.source" Bus1='+Sourcebus+' BasekV=33 Phases=3 pu=1.00 ISC3=3000 ISC1=2500 \n\n'

# 'Redirect LineCode.txt \n'
'Redirect Lines.txt \n'
'Redirect Transformers.txt \n'
'Redirect Loadshapes.txt \n'
'Redirect Generators.txt \n'
'Redirect Monitors.txt \n'
'Redirect Loads.txt \n\n'

'Set voltagebases=[33 11 0.4] \n'
'Calcvoltagebases \n\n'

'Buscoords XY_Position.txt'

)

f.close()

os.startfile(output+'Master.txt')

#%%
#=============================================================================
## Transformers ## 

NA='NA'

PT_HV = 'PT_HVbus'
PT_LV ='HV_joint93'

pt=[]        
for index, Prow in Primaries.iterrows():    
    pt.append('New Transformer.PT'+' '+\
              'Buses=['+PT_HV+' '+PT_LV+']'+' '+\
              'Conns=[Delta Wye]'+' '+\
              'Phases=3'+' '+\
              'Windings=2'+' '+\
              'kVs=['+str(Prow['SPPRIMVOLT'])+' '+str(Prow['SPSECVOLT'])+']'+' '+\
              'kVAs=['+str(Prow['SPCAPACITY']*1000)+' '+str(Prow['SPCAPACITY']*1000)+']'+' '+\
              'MaxTap=1.05'+' '+\
              'MinTap=0.84'+' '+\
              'NumTaps=21'+' '+\
               # 'XHL='+NA+' '+\
              'sub=Yes'+' '+\
              'subname=P_'+str(Prow['OBJECTID']))
        
reg = 'New RegControl.Reg1 Transformer=PT Winding=2 band=220 vreg=100 ptratio='+str((11200/math.sqrt(3))/100)+' '+'maxtapchange=1'     
        
st=[]        
for index, Srow in Secondaries.iterrows(): 
    st.append('New Transformer.ST_'+str(Srow['OBJECTID'])+' '+\
              'Buses=['+str(Srow['bus_name'])+'_HV'+' '+str(Srow['bus_name'])+'_LV'+']'+' '+\
              'Conns=[Delta Wye]'+' '+\
              'Phases=3'+' '+\
              'Windings=2'+' '+\
              'kVs=['+str(Srow['OPERATINGV']/1000)+' '+str(round((Srow['LOWSIDEVOL']/1000)*math.sqrt(3),1))+']'+' '+\
              'kVAs=['+str(Srow['SPTRANSRAT'])+' '+str(Srow['SPTRANSRAT'])+']'+' '+\
              # 'XHL='+NA+' '+\
              'sub=Yes'+' '+\
              'subname=S_'+str(Srow['OBJECTID']))
    
f = open(output+'Transformers.txt','w')
f.write('// Transformer Definitions \n\n')
f.write('// Primary Transformers \n\n')
for i in pt:
    f.write(i+'\n')
f.write('\n// OLTC AVR Control \n')  
f.write('\n'+reg+'\n')  
  
f.write('\n// Secondary Transformers \n\n')  
for i in st:
    f.write(i+'\n')
f.close()

os.startfile(output+'Transformers.txt')


#%%
#=============================================================================
## Lines ##

HV_Branches_Copy = HV_Branches.copy()

def linelength(name):
    length=[]
    for index, row in name.iterrows():
        length.append((row['geometry'].length)/1000)
    
    return length

HV_Branches['length_km'] = linelength(HV_Branches)
LV_Branches['length_km']  = linelength(LV_Branches)

def linegen(name):
    ''' OpenDSS Line Format Generator '''
    
    # New Line. = Line Name
    # Bus1 = Name of bus for terminal 1. Node order definitions optional.
    # Bus2 = Name of bus for terminal 2.
    # Phases = No. of phases. Default = 3. A line has the same number of 
    #          conductors per terminal as it has phases. neutrals are not 
    #          explicitly modelled unless declared as a "phase", and the
    #          impedance matrices must be augmented accordingly. For example,
    #          For example, a three-phase line has a 3x3 Z matrix with the 
    #          neutral reduced, or a 4x4 Z matrix with the neutral retained.
    # Linecode = Name of an existing LineCode object containing impedance 
    #            definitions.
    # Normamps = Normal ampacity, amps.
    # BaseFreq = Base Frequency at which the impedance values are specified. 
    #            Default = 60.0 Hz.
    # Length = Length multiplier to be applied to the impedance data.
    # Length Units = {none|mi|kft|km|m|Ft|in|cm} Default is None - assumes
    #                length units match impedance units.
    
    # Refer to OpenDSS Manual p130 if more properties are required.
    
    line=[]
    for index, row in name.iterrows():  
        line.append(\
                   'New Line.'+str(row['lineid'])+' '+\
                   'Bus1='+str(row['from_bus_name'])+' '+\
                   'Bus2='+str(row['to_bus_name'])+' '+\
                  # 'phases='+str(row['spnumofpha'])+' '+\
                   'phases=3'+' '+\
                   'R1='+str(row['R_ohm_km']) +' '+\
                   'X1='+str(row['X_ohm_km']) +' '+\
                   'Normamps='+str(row['Imax_A']) +' '+\
                   'Length='+str(row['length_km'])+' '+\
                   'Units=km')
    return line

hvline = linegen(HV_Branches_Copy)
lvline = linegen(LV_Branches_Copy)
   
f = open(output+'Lines.txt','w')
f.write(
'// Line Definitions \n\n'
'// Grid to Primary Transformer Terminal 1 Bus \n\n'
''+Line1+'\n\n'
'// HV Lines (11 kV) \n\n'
)

for i in hvline:
    f.write(i+'\n')
f.write('\n// LV Lines (<11kV) \n\n')    
for i in lvline:
    f.write(i+'\n')
f.close()

os.startfile(output+'Lines.txt')

#%%
#=============================================================================
## Coordinates ##

def coords(name):
    
    def editor(name1):
        res=str(row[name1]).replace('POINT (', '').replace(')', '')
        res=res.split(' ')
        return res
    
    res1=[]
    Bus_Names=[]
    for index, row in name.iterrows():
        res1.append(editor('from_bus'))
        res1.append(editor('to_bus'))
        Bus_Names.append(row['from_bus_name'])
        Bus_Names.append(row['to_bus_name'])
        
    x = [item[0] for item in res1]
    y = [item[1] for item in res1]
        
    df = pd.DataFrame({'Bus_Names':Bus_Names,'x':x,'y':y})    
    df = df.drop_duplicates()
    return df

f = open(output+'XY_Position.txt','w')
f.write('// Bus Coordinate Defintion \n\n')
f.write('// Bus_name, x, y\n\n')    

df = coords(HV_Branches)
for index, row in df.iterrows():    
    f.write(row['Bus_Names']+',\t'+str(row['x'])+',\t'+str(row['y'])+'\n')
    
df1 = coords(LV_Branches)
for index, row in df1.iterrows():    
    f.write(row['Bus_Names']+',\t'+str(row['x'])+',\t'+str(row['y'])+'\n')


res=str(Primaries['geometry'].iloc[0]).replace('POINT (', '').replace(')', '')
res=res.split(' ')
f.write(PT_HV+', '+res[0]+', '+res[1]+'\n')  

f.close()
 
os.startfile(output+'XY_Position.txt')

#%%
#=============================================================================
## Loads ##

loads_main = LV_Nodes.copy()

loads_main = loads_main[(loads_main[['sensor_cnt']] != 0).all(axis=1)]

def loadgen(name):
    ''' OpenDSS Load Generator '''
    
    # Refer to OpenDSS Manual p149 if more properties are required.
    
    NA = 'NA'
    
    load=[]
    for index, row in name.iterrows():
        
        if row['sensor_cnt'] == 1:
        
            load.append(\
                        'New Load.'+str(row['nodeid'])+' '+\
                        'Bus1='+str(row['bus_name'])+' '+\
                        'Phases=3'+' '+\
                        'kV=0.4'+' '+\
                        'kW=1'+' '+\
                        'PF=0.95'+' '+\
                        'daily=Profile_1'\
                          )
        else:
            for i in list(range(1,row['sensor_cnt']+1,1)):
            
                load.append(\
                    'New Load.'+str(row['nodeid'])+'_'+str(i)+' '+\
                    'Bus1='+str(row['bus_name'])+' '+\
                    'Phases=3'+' '+\
                    'kV=0.4'+' '+\
                    'kW=1'+' '+\
                    'PF=0.95'+' '+\
                    'daily=Profile_1'\
                  )
    return load

loads = loadgen(loads_main)

f = open(output+'Loads.txt','w')
f.write('// Load Definitions \n\n')
for i in loads:
    f.write(i+'\n')
f.close()

os.startfile(output+'Loads.txt')


#%%
#=============================================================================
## Loadshapes ##

case = 2 # 1 = no dg, 2 = dg, 3 = no dg and storage

filenames = glob.glob(lc_path + "/*.csv") # obtains all filenames in the folder
pre_lc=[pd.read_csv(i, index_col=None, header=None) for i in filenames]  # brings each curve into a list of individual dataframes
allLS=pd.concat(pre_lc, axis=1, ignore_index=True) # concentrates the list of individual dataframes into a single dataframe
allLS.columns=[os.path.splitext(os.path.basename(i))[0] for i in filenames] # assigns the curve name to each column in dataframe

filenames1 = glob.glob(gc_path + "/*.csv")
pre_gc=[pd.read_csv(X, index_col=None, header=None) for X in filenames1]  
allGS=pd.concat(pre_gc, axis=1, ignore_index=True)
allGS.columns=[os.path.splitext(os.path.basename(X))[0] for X in filenames1] 

def loadshape(name,entity):
    ls=[]
    for i in name.columns:

            ls.append(\
                        'New Loadshape.'+i+' npts=48 interval=0.5 UseActual='+entity+' mult='+str(name[i].tolist())
                          )
    return ls

loadshapes = loadshape(allLS,'false')
genshapes = loadshape(allGS,'true')

f = open(output+'Loadshapes.txt','w')
f.write('// Loadshape Definitions \n\n')
print(case)
if case == 1 or case == 3:
    for i in loadshapes:
        f.write(i+'\n')
        print('test')
elif case == 2:
    for i in loadshapes:
        f.write(i+'\n')
    for j in genshapes:
        print(j)
        f.write(j+'\n')    
    
f.close()

os.startfile(output+'Loadshapes.txt')

#%%
#=============================================================================
## Generators ##

diesel_gen = 'New Generator.Diesel_Gen bus1='+PT_LV+' kV=11 kW=100 pf=1 phases=3 enabled=NO'

bat_stor = (\
            '// Energy Storage \n\n'
            'New Storage.PBESS phases=3 Bus='+PT_LV+' kV=11 \n'
            '~ kWrated=250 kWHrated=1000 \n'
            '~ state=idling \n'
            '~ kW=50 pf=1 \n'
            '~ debugtrace=Yes \n'
            '~ DispMode=External \n'
            '~ %reserve=25 \n'
            '~ %IdlingkW=1 \n'
            '~ %EffCharge=90 \n'
            '~ %EffDischarge=90 \n'
            )

def gengen(name):
    ''' OpenDSS Load Generator '''
    
    # Refer to OpenDSS Manual p149 if more properties are required.
    
    NA = 'NA'
    
    load=[]
    for index, row in name.iterrows():
        
            load.append(\
                        'New Generator.'+str(row['nodeid'])+' '+\
                        'Bus1='+str(row['bus_name'])+' '+\
                        'Phases=3'+' '+\
                        'kV=0.4'+' '+\
                        'kW=2'+' '+\
                        'PF=1'+' '+\
                        'daily=Gen_1'\
                          )
    return load

gens = gengen(loads_main)



f = open(output+'Generators.txt','w')

f.write('// Generator Definitions \n\n')

if case == 1:
    f.write(diesel_gen+'\n')
elif case == 2:
    f.write(diesel_gen+'\n\n')
    # f.write(dg1+'\n')
    # f.write(dg2+'\n')
    
    for i in gens:
        f.write(i+'\n')

elif case == 3:
     f.write(diesel_gen+'\n\n')   
     f.write(bat_stor+'\n\n')   
f.close()

os.startfile(output+'Generators.txt')

#%%
#=============================================================================
## Monitors ##

a0 = 'New monitor.TS2_power element=Transformer.PT terminal=1 mode=1 ppolar=no'
a1 = 'New Monitor.TS2_voltage element=Transformer.PT terminal=1 Mode=0'

b0 = 'New monitor.G1_power element=Generator.Diesel_Gen terminal=1 mode=1 ppolar=no'
b1 = 'New Monitor.G1_voltage element=Generator.Diesel_Gen terminal=1 Mode=0'

# c0 = 'New monitor.BESS_power element=Storage.PBESS terminal=1 mode=1 ppolar=no'
# c1 = 'New monitor.BESS_power_2 element=Storage.PBESS terminal=1 mode=3 ppolar=no'
    

f = open(output+'Monitors.txt','w')
f.write('// Monitor Definitions \n\n')
f.write(a0+'\n')
f.write(a1+'\n\n')
f.write(b0+'\n')
f.write(b1+'\n\n')
# f.write(c0+'\n')
# f.write(c1+'\n')
f.close()

os.startfile(output+'Monitors.txt')