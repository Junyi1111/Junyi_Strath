import pickle
import pandapower as pp
import matplotlib.pyplot as plt
import mplleaflet
import geopandas as gp
import pandas as pd


mwd = 'C:\\Users\\xsb17172\\Desktop\\Network\\'
insert = mwd +'GIS_Data\\'

Primaries = gp.read_file(insert+'\\PrimarySub.shp')
Secondaries = gp.read_file(insert+'\\SecondarySub.shp')
HV_Cables = gp.read_file(insert+'\\HVCable.shp')
# HV_OHL = gp.read_file(insert+'\\HVOHLine.shp')


#%%            
## ======================================================================== ##
## Python Figure

figure_1, ax = plt.subplots()

ax.set_aspect('equal')

HV_Cables.plot(ax=ax, color='black', linewidth = 1, zorder=3)
# HV_OHL.plot(ax=ax, color='red', linewidth = 1, zorder=3)
Secondaries.plot(ax=ax, color='blue', marker='8', markersize=20, zorder=4)
Primaries.plot(ax=ax, color='red', marker='s', markersize=45, zorder=5)

plt.show()

#%%
## ======================================================================== ##
## Interactive Figure (Takes Time to Compile)

f, ax = plt.subplots()
Secondaries.plot(ax=ax, color='blue', marker='8', markersize=20, zorder=4)
Primaries.plot(ax=ax, color='red', marker='s', markersize=45, zorder=5)
HV_Cables.plot(ax=ax, color = 'black', zorder=3)

mplleaflet.show(fig=f.figure, crs=HV_Cables.crs)